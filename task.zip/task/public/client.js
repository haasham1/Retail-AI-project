const chat = document.getElementById('chat');
const form = document.getElementById('chat-form');
const input = document.getElementById('user-input');

function addMessage(role, text) {
  const el = document.createElement('div');
  el.className = `msg ${role}`;
  el.textContent = text;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}

async function send(message) {
  addMessage('user', message);
  input.value = '';
  input.disabled = true;

  try {
    const resp = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message })
    });
    const data = await resp.json();
    if (data.reply) {
      addMessage('assistant', data.reply);
    } else if (data.error) {
      addMessage('assistant', `Error: ${data.error}`);
    } else {
      addMessage('assistant', 'No response');
    }
  } catch (err) {
    addMessage('assistant', `Network error: ${String(err)}`);
  } finally {
    input.disabled = false;
    input.focus();
  }
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (text) {
    send(text);
  }
});

addMessage('assistant', 'Hi! Ask me to find products, compute totals, or convert currencies.');

// image functionality removed


