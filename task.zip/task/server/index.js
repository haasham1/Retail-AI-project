import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import OpenAI from 'openai';
import { GoogleGenerativeAI } from '@google/generative-ai';

import { productSearchTool, runProductSearch } from './tools/productSearch.js';
import { cartCalculatorTool, runCartCalculation } from './tools/cartCalculator.js';
import { currencyConverterTool, runCurrencyConversion } from './tools/currencyConverter.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Lazily instantiate the OpenAI client inside the route so the server can boot without an API key

// Serve static UI
app.use(express.static(path.join(__dirname, '..', 'public')));

const tools = [productSearchTool, cartCalculatorTool, currencyConverterTool];

function extractParams(text) {
  const out = {
    quantity: 1,
    taxRatePct: 0,
    discountPct: 0,
    currency: null,
    priceUnder: null
  };

  const qtyMatch = text.match(/(?:for\s+)?(\d+)\s*(?:units?|pcs?|pieces?|items?)\b|x(\d+)/i);
  if (qtyMatch) {
    out.quantity = Number(qtyMatch[1] || qtyMatch[2]);
  }

  const taxMatch = text.match(/(\d+(?:\.\d+)?)\s*%[^\n]*?tax/i);
  if (taxMatch) out.taxRatePct = Number(taxMatch[1]);

  const discMatch = text.match(/(\d+(?:\.\d+)?)\s*%[^\n]*?discount/i);
  if (discMatch) out.discountPct = Number(discMatch[1]);

  const curMatch = text.match(/\b(?:in|to)\s+([A-Z]{3})\b/);
  if (curMatch) out.currency = curMatch[1].toUpperCase();

  const underMatch = text.match(/(?:under|below)\s*\$?\s*(\d+(?:\.\d+)?)/i);
  if (underMatch) out.priceUnder = Number(underMatch[1]);

  // Build a simple query by removing some control phrases
  let query = text
    .replace(/(?:for\s+)?\d+\s*(?:units?|pcs?|pieces?|items?)\b/gi, '')
    .replace(/x\d+/gi, '')
    .replace(/\d+\s*%\s*(?:tax|discount)/gi, '')
    .replace(/(?:in|to)\s+[A-Z]{3}/gi, '')
    .replace(/(?:under|below)\s*\$?\s*\d+(?:\.\d+)?/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!query) query = text.trim();
  out.query = query;
  return out;
}

async function demoRespond(userText) {
  const { query, quantity, taxRatePct, discountPct, currency, priceUnder } = extractParams(userText);
  const search = await runProductSearch({ query, maxResults: 5, priceUnder });
  const top = search.products?.[0];
  if (!top) {
    return `I couldn't find any products for "${query}"${priceUnder ? ` under $${priceUnder}` : ''}. Try another keyword.`;
  }

  const cart = await runCartCalculation({
    items: [
      {
        id: top.id,
        title: top.title,
        unitPrice: top.price,
        quantity
      }
    ],
    taxRatePct,
    discountPct
  });

  let lines = [
    `- Found: ${top.title} — $${top.price.toFixed(2)} USD`,
    `- Quantity: x${quantity}`,
    `- Subtotal: $${cart.subtotal.toFixed(2)} USD`,
    `- Discount (${discountPct}%): $${cart.discount.toFixed(2)} USD`,
    `- Tax (${taxRatePct}%): $${cart.tax.toFixed(2)} USD`,
    `- Total: $${cart.total.toFixed(2)} USD`
  ];

  if (currency && currency !== 'USD') {
    const conv = await runCurrencyConversion({ amount: cart.total, from: 'USD', to: currency });
    if (!conv.error) {
      lines.push(`- Total in ${currency}: ${conv.convertedAmount} (${conv.rate?.toFixed ? conv.rate.toFixed(4) : conv.rate} rate)`);
    }
  }

  return lines.join('\n');
}

app.post('/api/chat', async (req, res) => {
  const { message } = req.body || {};
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Missing message' });
  }

  try {
    const apiKey = process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY;
    const useGemini = Boolean(process.env.GEMINI_API_KEY);
    const demoMode = (!apiKey && !useGemini) || String(process.env.DEMO_MODE).toLowerCase() === 'true';
    if (demoMode) {
      const reply = await demoRespond(message);
      return res.json({ reply });
    }
    if (useGemini) {
      const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      const prompt = `You are RetailAI Shopper Assistant. Keep responses concise.\nUser: ${message}`;
      const result = await model.generateContent(prompt);
      const text = result.response.text();
      return res.json({ reply: text });
    }
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const messages = [
      {
        role: 'system',
        content:
          'You are RetailAI Shopper Assistant. Use tools when helpful. Keep responses short and structured with bullet points and totals. '
      },
      { role: 'user', content: message }
    ];

    // Tool-calling loop (bounded)
    for (let i = 0; i < 4; i += 1) {
      const response = await client.chat.completions.create({
        model: 'gpt-4o-mini',
        messages,
        tools,
        tool_choice: 'auto',
        temperature: 0.3
      });

      const choice = response.choices[0];
      const msg = choice.message;

      // If there are tool calls, execute them and continue the loop
      if (msg.tool_calls && msg.tool_calls.length > 0) {
        messages.push({ role: 'assistant', content: msg.content ?? '', tool_calls: msg.tool_calls });

        for (const call of msg.tool_calls) {
          const toolName = call.function.name;
          const toolArgs = JSON.parse(call.function.arguments || '{}');
          let toolResult;

          if (toolName === productSearchTool.function.name) {
            toolResult = await runProductSearch(toolArgs);
          } else if (toolName === cartCalculatorTool.function.name) {
            toolResult = await runCartCalculation(toolArgs);
          } else if (toolName === currencyConverterTool.function.name) {
            toolResult = await runCurrencyConversion(toolArgs);
          } else {
            toolResult = { error: `Unknown tool: ${toolName}` };
          }

          messages.push({
            role: 'tool',
            tool_call_id: call.id,
            name: toolName,
            content: JSON.stringify(toolResult)
          });
        }
        continue; // query model again with tool results
      }

      // No tool calls → final answer
      return res.json({ reply: msg.content });
    }

    return res.json({ reply: 'Request exceeded tool call limit. Try a more specific prompt.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error', detail: String(err) });
  }
});

app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});


