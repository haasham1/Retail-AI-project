import fetch from 'node-fetch';

export const productSearchTool = {
  type: 'function',
  function: {
    name: 'product_search',
    description:
      'Search products by keyword. Returns compact product info with title, price, category, rating, and id.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search keyword, e.g., laptop' },
        maxResults: { type: 'number', description: 'Max number of items to return', default: 5 },
        priceUnder: { type: 'number', description: 'Filter to items with price <= this value' }
      },
      required: ['query']
    }
  }
};

export async function runProductSearch(args) {
  const { query, maxResults = 5, priceUnder } = args || {};
  const url = 'https://fakestoreapi.com/products';
  const resp = await fetch(url);
  if (!resp.ok) {
    return { error: 'Product API failed' };
  }
  const data = await resp.json();
  const lower = String(query || '').toLowerCase();
  let items = data
    .filter((p) =>
      p.title.toLowerCase().includes(lower) || p.description.toLowerCase().includes(lower)
    )
    .map((p) => ({ id: String(p.id), title: p.title, price: Number(p.price), category: p.category, rating: p.rating?.rate ?? null }));

  if (typeof priceUnder === 'number') {
    items = items.filter((i) => i.price <= priceUnder);
  }
  items = items.slice(0, maxResults);
  return { products: items };
}


