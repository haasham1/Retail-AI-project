import fetch from 'node-fetch';

export const currencyConverterTool = {
  type: 'function',
  function: {
    name: 'currency_convert',
    description: 'Convert an amount between currencies using latest exchange rate.',
    parameters: {
      type: 'object',
      properties: {
        amount: { type: 'number' },
        from: { type: 'string', description: 'ISO currency code, e.g., USD' },
        to: { type: 'string', description: 'ISO currency code, e.g., EUR' }
      },
      required: ['amount', 'from', 'to']
    }
  }
};

export async function runCurrencyConversion(args) {
  const { amount, from, to } = args || {};
  const base = 'https://api.exchangerate.host/convert';
  const url = `${base}?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&amount=${encodeURIComponent(amount)}`;
  const resp = await fetch(url);
  if (!resp.ok) {
    return { error: 'FX API failed' };
  }
  const data = await resp.json();
  if (!data || typeof data.result !== 'number') {
    return { error: 'Invalid FX response' };
  }
  const rate = data.info?.rate ?? (Number(data.result) / Number(amount));
  return { convertedAmount: Number(data.result.toFixed(2)), rate: Number(rate) };
}


