export const cartCalculatorTool = {
  type: 'function',
  function: {
    name: 'cart_calculate',
    description:
      'Compute line totals, subtotal, tax, discount, and grand total for a shopping cart.',
    parameters: {
      type: 'object',
      properties: {
        items: {
          type: 'array',
          description: 'Cart items',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              title: { type: 'string' },
              unitPrice: { type: 'number' },
              quantity: { type: 'number' }
            },
            required: ['title', 'unitPrice', 'quantity']
          }
        },
        taxRatePct: { type: 'number', description: 'Tax rate percentage', default: 0 },
        discountPct: { type: 'number', description: 'Discount percentage', default: 0 }
      },
      required: ['items']
    }
  }
};

export async function runCartCalculation(args) {
  const { items = [], taxRatePct = 0, discountPct = 0 } = args || {};
  const lineItems = items.map((it) => {
    const quantity = Number(it.quantity || 0);
    const unitPrice = Number(it.unitPrice || 0);
    const lineTotal = Number((quantity * unitPrice).toFixed(2));
    return { ...it, quantity, unitPrice, lineTotal };
  });

  const subtotal = Number(
    lineItems.reduce((sum, it) => sum + (it.lineTotal || 0), 0).toFixed(2)
  );
  const discount = Number(((subtotal * (Number(discountPct) || 0)) / 100).toFixed(2));
  const taxable = Math.max(0, subtotal - discount);
  const tax = Number(((taxable * (Number(taxRatePct) || 0)) / 100).toFixed(2));
  const total = Number((taxable + tax).toFixed(2));

  return { lineItems, subtotal, discount, tax, total };
}


